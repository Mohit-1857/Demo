package com.example.test.Credentials.ViewModel

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.util.prefs.Preferences

class UserDataStore(user: String) {
//    private val Context.datastore: DataStore<Preferences> by preferencesDataStore("User")
//    private val user = stringPreferencesKey(user)
}