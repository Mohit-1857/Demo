package com.example.test.Credentials

data class User(val email : String , val password : String)
