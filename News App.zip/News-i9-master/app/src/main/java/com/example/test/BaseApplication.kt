package com.example.test

import android.app.Application
import dagger.hilt.android.HiltAndroidApp


@HiltAndroidApp
open class BaseApplication : Application() {

}